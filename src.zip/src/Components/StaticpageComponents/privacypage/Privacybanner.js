import React from 'react'

function Privacybanner() {
  return (
    <section className='banner-part privacy-banner'>
      <div className='container'>
        <div className='row'>
          <div className='col-12'>
            <h1>Privacy Policy</h1>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Privacybanner