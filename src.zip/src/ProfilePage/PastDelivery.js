import React from 'react' 
import Layout from '../Components/DashboardLayout/Layout'

const PastDelivery = () => {
  return (
    <Layout>

      
    </Layout>
  )
}

export default PastDelivery